<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CheckoutController--resource extends Controller
{
    //
}
